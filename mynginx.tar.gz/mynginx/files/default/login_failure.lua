local template = require "resty.template"

template.render("login.html", {
    script = "<script>$( document ).ready(function() {$('.login-error').css('display', 'block');$('.form-signin').css('height', '305px');$('.submit').css('margin-top', '0'); }); </script>"
})
