--
-- Script for inital login. Checks Username and password
-- via Cerberus, selects any sticky sessions required
-- and 'unsets' the SMIWeb and Scheduler cookies.
-- Author: Patrick Auld
-- Date: 11/28/16
-- Time: 4:37 PM
--

local upstream = require "ngx.upstream"
local get_servers = upstream.get_servers

-- TODO Combine these blocks into a methods.
local servers, err = get_servers("birst")
if not servers then
    ngx.log(ngx.ERR, "Failed to get servers from upstream birst.")
    return ngx.redirect("/login.html")
end

local num_servers = table.maxn(servers)
local selected_server_index = math.random(num_servers)
local selected_server = servers[selected_server_index]["addr"]
local selected_server_base64 = ngx.encode_base64(selected_server)

-- TODO Combine with the above code.
local metadata_servers, err = get_servers("metadataService")
if not metadata_servers then
    ngx.log(ngx.ERR, "Failed to get servers from upstream birst.")
    return ngx.redirect("/login.html")
end

local num_servers_meta = table.maxn(metadata_servers)
local selected_metadata_server_index = math.random(num_servers_meta)
local selected_metadata_server = metadata_servers[selected_metadata_server_index]["addr"]
local selected_metadata_server_base64 = ngx.encode_base64(selected_metadata_server)

local resty_random = require "resty.random"
local str = require "resty.string"
local strong_random = resty_random.bytes(16,true)
local xsrfToken = str.to_hex(strong_random)

-- removing SMIWeb and Scheduler cookies to force a fresh session upon login
-- all cookies aside from the XSRF Token ought to be HttpOnly
ngx.header['Set-Cookie'] = {
    "NgStickySrv=" .. selected_server_base64 .. "; path=/; HttpOnly;",
    "NgStickyMetadataSrv=" .. selected_metadata_server_base64 .. "; path=/; HttpOnly;",
    "XSRF-TOKEN=" .. xsrfToken .. "; path=/;",
    "JSESSIONID=; path=/; HttpOnly; Max-Age=0;",
    "BSJSESSIONID=; path=/; HttpOnly; Max-Age=0;",
    "ASP.NET_SessionId=; path=/; HttpOnly; Max-Age=0;",
    ".ASPXFORMSAUTH=; path=/; HttpOnly; Max-Age=0;"
}
