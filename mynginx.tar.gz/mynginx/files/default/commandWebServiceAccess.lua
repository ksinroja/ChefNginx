--
-- Command Web Services requires a slightly different flow.
-- This selects the upstreams on demand. This code can likely
-- be combined with the login and access scripts eventually.
-- Author: Patrick Auld
-- Date: 11/28/16
-- Time: 4:38 PM
--

local sticky_routing = ngx.var["cookie_NgStickySrv"]
if sticky_routing then
    ngx.var.upstream_host = ngx.decode_base64(sticky_routing)
else
    local upstream = require "ngx.upstream"
    local get_servers = upstream.get_servers
    local servers, err = get_servers("birst")
    if not servers then
        ngx.log(ngx.ERR, "Failed to get servers from upstream birst.")
        return ngx.redirect("/login.html")
    else
        local num_servers = table.maxn(servers)
        local selected_server_index = math.random(num_servers)
        local selected_server = servers[selected_server_index]["addr"]
        local selected_server_base64 = ngx.encode_base64(selected_server)
        ngx.header['Set-Cookie'] = {"NgStickySrv=" .. selected_server_base64 .. "; path=/; HttpOnly"}
        ngx.var.upstream_host = selected_server
    end
end

