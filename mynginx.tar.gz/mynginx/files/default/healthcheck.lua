local hc = require 'resty.upstream.healthcheck'

function spawn_healthchecker(hc, upstream, check_request)
    local ok, err = hc.spawn_checker {
        shm = 'healthcheck',
        upstream = upstream,
        type = 'http',
        http_req = check_request,
        valid_statuses = {200, 201, 302},
        interval = 2000, -- run the check cycle every 2 sec
        timeout = 2000, -- 2 sec is the timeout for network operations
        fall = 2, -- # of successive failures before turning a peer down
        rise = 2 -- # of successive successes before turning a peer up
    }
    if not ok then
        ngx.log(ngx.ERR, "Failed to spawn health checker for " + upstream, err)
    end
end

spawn_healthchecker(hc, 'birst', 'GET /Health.aspx HTTP/1.0\r\n\r\n')
spawn_healthchecker(hc, 'metadataService', 'GET /MetadataService/healthcheck HTTP/1.0\r\n\r\n')
spawn_healthchecker(hc, 'cerberus', 'GET /cerberus/healthcheck HTTP/1.0\r\n\r\n')
spawn_healthchecker(hc, 'connectorsController', 'POST /ConnectorController/rest/v1/connectors/health HTTP/1.0\r\n\r\n')
spawn_healthchecker(hc, 'avatar', 'GET /avatar/healthcheck HTTP/1.0\r\n\r\n')
