--
-- Script for token based authentication via Cerberus.
-- Authenticates the given token and if valid
-- sets headers in the response of auth request.
-- Author: Dhwaneet Bhatt
-- Date: 08/25/16
--

----
-- METHOD DEFINITION BLOCK
----

---
-- Fetches token information from Cerberus
-- @param token
--
function getTokenDetails(token)
    for i=1,3,1 do
        -- pcall wraps and return false for success if an exception is encountered
        local success, res = pcall(ngx.location.capture, "/tokens/auth", {args = token})

        -- Only is there was not an error and we got a 200 back do we return
        if success and res.status == 200 then
            return res
        end
    end
    ngx.log(ngx.WARN, "Failed to verify token with Cerberus within 3 retries.")
    return nil
end

---
-- Checks if a given token is valid or not
-- Returns a unauthorized error if not valid
-- @param token
---
function authToken(token)
    local res = getTokenDetails(token);
    if not res then
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end
    validateAccess(res)

    credentials = {}
    credentials["BIRST-USERNAME"] = res.header["BIRST-USERNAME"]
    credentials["BIRST-USERID"] = res.header["BIRST-USERID"]
    credentials["BIRST-ACCOUNTID"] = res.header["BIRST-ACCOUNTID"]
    return credentials
end

---
-- Checks if the response is valid
-- and required_scope is present
-- Returns unauthorized error if not valid
-- @param response
---
function validateAccess(res)
    local valid = res.header["valid"]
    if not valid or valid == false then
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end

    local scope = res.header["BIRST-SCOPE"]
    if not scope then
        ngx.log(ngx.WARN, "Attempt to access a proctected resource without any scope. Preventing access.")
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end

    local idx = string.find(scope, ngx.var.required_scope)
    if not idx then
        ngx.log(ngx.WARN, "Required scope: " .. ngx.var.required_scope .. ". Preventing access.")
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end
end

----
-- REGULAR CODE BLOCK (NO METHODS BELOW THIS)
----

-- Verify the access token is present in the Authorization header
local auth_header = ngx.req.get_headers()["Authorization"]
if not auth_header or string.sub(auth_header, 1, 6) ~= "Bearer" then
    ngx.log(ngx.WARN, "Unknown authentication type, expected Bearer")
    ngx.exit(ngx.HTTP_UNAUTHORIZED)
end
local access_token = string.sub(auth_header, 8)
if not access_token then
    ngx.log(ngx.WARN, "Access token not part of Authorization header")
    ngx.exit(ngx.HTTP_UNAUTHORIZED)
end

-- Calls Cerberus with the access_token to check if it is valid
-- Will hit a local side cache first to check
-- If valid then headers with request metadata are set for the proxy_pass
local credentials = auth_cache:get(access_token)
if not credentials then
    credentials = authToken(access_token)
    auth_cache:set(access_token, credentials, 3)
end

ngx.req.set_header("BIRST-USERNAME", credentials["BIRST-USERNAME"])
ngx.req.set_header("BIRST-USERID", credentials["BIRST-USERID"])
ngx.req.set_header("BIRST-ACCOUNTID", credentials["BIRST-ACCOUNTID"])