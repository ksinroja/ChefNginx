local template = require "resty.template"

template.render("login.html", { script = '' })
