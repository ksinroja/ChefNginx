----
-- METHOD DEFINITION BLOCK
----

---
-- Checks all CSRF attack points
---
function checkCsrfAttempt()
    -- Skip both referer, origin and CSRF checks if set to false.
    if ngx.var.csrf_validation == 'false' then
        return
    end
    -- replace any dashes as Lua sees them as regex markers
    local baseUriPattern = "https?://" .. string.gsub(ngx.var.host, "%-", "%%-")
    validateXSRF()
    validateReferer(baseUriPattern)
    validateOrigin(baseUriPattern)
end

---
-- Check the XSRF header matches the cookie
-- Exits with Forbidden if check fails
---
function validateXSRF()
    local h_xsrf_token = ngx.req.get_headers()["X-XSRF-TOKEN"]
    if h_xsrf_token ~= ngx.var["cookie_XSRF-TOKEN"] then
        ngx.log(ngx.WARN, "CSRF Attempt detected. Preventing access.")
        ngx.exit(ngx.HTTP_FORBIDDEN)
    end
end

---
-- Check the referer headers match the host
-- Exits with Forbidden if check fails
---
function validateReferer(baseUriPattern)
    local h_referer = ngx.req.get_headers()["Referer"]
    if (h_referer ~= nil) then
        local idx = string.find(h_referer, baseUriPattern)
        if idx ~= 1 then
            ngx.log(ngx.WARN, "CSRF Attempt detected. Referer did not match. Preventing access. Base host: " .. baseUriPattern .. " and referer: " .. h_referer)
            if idx == nil then
                ngx.log(ngx.WARN, "URLs did not match at all.")
            else
                ngx.log(ngx.WARN, "URL match at " .. idx)
            end
            ngx.exit(ngx.HTTP_FORBIDDEN)
        end
    end
end

---
-- Checks the Origin header
-- Exits with Forbidden if check fails
---
function validateOrigin(baseUriPattern)
    local h_origin = ngx.req.get_headers()["Origin"]
    if (h_origin ~= nil) then
        local idx = string.find(h_origin, baseUriPattern)
        if idx ~= 1 then
            ngx.log(ngx.WARN, "CSRF Attempt detected. Origin did not match. Preventing access.")
            ngx.exit(ngx.HTTP_FORBIDDEN)
        end
    end
end

---
-- Fetches token information from Cerberus
-- @param token token to check in Cerberus
--
function getTokenDetails(token)
    for i=1,3,1 do
        -- pcall wrappes and return false for success if an exception is encoutered
        local success, res = pcall(ngx.location.capture, "/auth", {args = token})

        -- Only is there was not an error and we got a 200 back do we return
        if success and res.status == 200 then
            return res
        end
    end
    ngx.log(ngx.WARN, "Failed to verify token with Cerberus within 3 retries. Bouncing to login page.")
    return nil
end

---
-- Checks if a given token is valid or not, returns the login
-- details if it is. Otherwise exits with a redirect to the login
-- page if it is not valid.
-- @param token
--
function authToken(token)
    local res = getTokenDetails(token);
    if not res then
        return ngx.redirect("/login.html")
    end
    local valid = res.header["valid"]

    if not valid or valid == false then
        return ngx.redirect("/login.html")
    end

    credentials = {}
    credentials["BIRST-USERNAME"] = res.header["BIRST-USERNAME"]
    credentials["BIRST-USERID"] = res.header["BIRST-USERID"]
    credentials["BIRST-ACCOUNTID"] = res.header["BIRST-ACCOUNTID"]
    credentials["BIRST-SESSIONID"] = res.header["BIRST-SESSIONID"]
    return credentials;
end

----
-- REGULAR CODE BLOCK (NO METHODS BELOW THIS)
----

local sticky_routing = ngx.var["cookie_NgStickySrv"]
local metadataServiceSticky_routing = ngx.var["cookie_NgStickyMetadataSrv"]

-- Check if we're hitting the metadata service first and use that cookie if so
-- Otherwise use the other sticky cookie if its set
-- Return to login if all else fails.
if ngx.var.access_point == "MetadataService" then
    local host = ngx.decode_base64(metadataServiceSticky_routing)
    ngx.log(ngx.DEBUG, "Sticky session for MetadataService found, redirecting request to " .. host)
    ngx.var.upstream_host = host

elseif ngx.var.access_point == "ConnectorController" then
    --TODO refactor this so we don't just have empty blocks
    -- The upstream for ConnectorController is balanced by Nginx so no ngx.var.upstream_host needs to be set.

elseif ngx.var.access_point == "avatar" then
    --TODO refactor this so we don't just have empty blocks
    -- The upstream for Avatar is balanced by Nginx so no ngx.var.upstream_host needs to be set.

elseif ngx.var.access_point == "cerberus" then
    --TODO refactor this so we don't just have empty blocks
    -- The upstream for Cerberus is balanced by Nginx so no ngx.var.upstream_host needs to be set.

elseif sticky_routing then
    local birst_host = ngx.decode_base64(sticky_routing)
    ngx.log(ngx.DEBUG, "Sticky session for birst_host found, redirecting request to " .. birst_host)
    if ngx.var.access_point == "base" then
        ngx.var.upstream_host = birst_host
    elseif ngx.var.access_point == "SMIWeb" then
        ngx.var.upstream_host = string.gsub(birst_host, ":(%d+)", ":6101")
    elseif ngx.var.access_point == "Scheduler" or ngx.var.access_point == "heartwood" then
        ngx.var.upstream_host = string.gsub(birst_host, ":(%d+)", ":6701")
    else
        ngx.log(ngx.ERR, "Unknown access point for access validation.")
        return ngx.redirect("/login.html");
    end
else
    ngx.log(ngx.DEBUG, "No sticky session cookie found.")
    return ngx.redirect("/login.html")
end

-- Verify the birst-token is set at all
local birst_token = ngx.var["cookie_birst-token"]
if not birst_token then
    ngx.log(ngx.ERR, "birst token was missing")
    return ngx.redirect("/login.html")
end

-- protect ourselves against CSRF attacks
checkCsrfAttempt()

-- Calls Cerberus with the birst-token cookie to check if it is valid.
-- Will hit a local side cache first to check
-- If valid then headers with request metadata are set for the proxy_pass
local credentials = auth_cache:get(birst_token)
if not credentials then
    credentials = authToken(birst_token)
    auth_cache:set(birst_token, credentials, 3)
end

ngx.req.set_header("BIRST-USERNAME", credentials["BIRST-USERNAME"])
ngx.req.set_header("BIRST-USERID", credentials["BIRST-USERID"])
ngx.req.set_header("BIRST-ACCOUNTID", credentials["BIRST-ACCOUNTID"])
ngx.req.set_header("BIRST-SESSIONID", credentials["BIRST-SESSIONID"])
