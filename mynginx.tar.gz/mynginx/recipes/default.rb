#
# Cookbook:: mynginx
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.
package 'git'
package 'tree'

package 'nginx' do
  action :install
end

service 'nginx' do
  action [ :enable, :stop ]
end



cookbook_file "/usr/share/nginx/html/index.html" do
  source "index.html"
  mode "0644"
end

template "/etc/nginx/nginx.conf" do
  variables(
    'port_id': 28282
  )
  source "nginx.conf.erb"
end

service 'nginx' do
  action [ :enable, :start ]
end
